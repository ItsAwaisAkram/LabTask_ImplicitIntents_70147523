package com.example.uoltransportdesk;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static final String EXTRA_NAME = "extra_student_name";

    private EditText etName;

    public static void openIntent(Context context, Intent intent) {
        try {
            context.startActivity(intent);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "No app found for this action", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        Button btnPage = findViewById(R.id.btnPage);
        Button btnCallOffice = findViewById(R.id.btnCallOffice);
        Button btnBusStop = findViewById(R.id.btnBusStop);
        Button btnReport = findViewById(R.id.btnReport);

        btnPage.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.uol.edu.pk"));
            openIntent(MainActivity.this, intent);
        });

        btnCallOffice.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:04298765432"));
            openIntent(MainActivity.this, intent);
        });

        btnBusStop.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("geo:0,0?q=Thokar+Niaz+Baig,+Lahore"));
            openIntent(MainActivity.this, intent);
        });

        btnReport.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            if (name.isEmpty()) {
                etName.setError("Please enter your name");
                return;
            }
            Intent intent = new Intent(MainActivity.this, ProblemActivity.class);
            intent.putExtra(EXTRA_NAME, name);
            startActivity(intent);
        });
    }
}